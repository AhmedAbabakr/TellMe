<footer class="site-footer">
          <div class="text-center">
              2019 &copy; <a href="http://hashcode.me/" target="_blank" style="color: #fff;">Hash Code.</a>
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
