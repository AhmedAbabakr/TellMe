<?php $__env->startSection('content'); ?>

     <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
                              <li class="breadcrumb-item"><a href="<?php echo e(route('branch.index')); ?>">Company Branches</a></li>
                             <li class="breadcrumb-item"><span><?php echo e($branch->branch_name); ?></span></li>
                              <li class="breadcrumb-item " ><a href="<?php echo e(route('branch.assign.index',encrypt($branch->branch_id))); ?>"><?php echo e($branch->branch_name); ?> Questions</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Assign Question</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                         <div class="card-body">
                      <?php if($errors->any()): ?>
                          <div class="alert alert-danger">
                              <ul>
                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><?php echo e($error); ?></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </div>
                      <?php endif; ?>
                              <form class="form-horizontal tasi-form" method="POST" action="<?php echo e(route('branch.assign.post',encrypt($branch->branch_id))); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('POST'); ?>
                               
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label col-lg-2 mb-3" >Questions </label>
                                       <?php if($questions->count() > 0): ?>
                                      <div class="col-lg-10">
                                         <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <div class="custom-control custom-checkbox mb-3">
                                              <input type="checkbox" class="custom-control-input" id="customCheck<?php echo e($question->question_id); ?>" name="questions[]" value="<?php echo e($question->question_id); ?>">
                                              <label class="custom-control-label" for="customCheck<?php echo e($question->question_id); ?>"><?php echo e($question->question_content_en); ?></label>
                                          </div>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </div>
                                      <?php else: ?>
                                      <div class="col-lg-10">
                                        <p>No questions available to assign </p>
                                      </div>
                                      <?php endif; ?>
                                  </div>
                                
                                  
                                    
                                 
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                        <?php if($questions->count() > 0): ?>
                                          <button class="btn btn-danger" type="submit">Save</button>
                                        <?php endif; ?>
                                          <a href="<?php echo e(route('branch.assign.index',encrypt($branch->branch_id))); ?>" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                       
                           
                         </div>
                      </section>
                </div>
              </div>
              <script type="text/javascript">
<?php if( isset($html) ): ?>
 $("#1").append(<?php echo e($html); ?>)
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/branches/question/create.blade.php ENDPATH**/ ?>