<?php for($i=0;$i < 3 ;$i++): ?>
<div class="form-group">
    <label class="col-sm-2 control-label">Option English Text</label>
    <div class="col-sm-10">
        <input type="text" class="required form-control <?php if($errors->has('option_text_en')): ?> is-valid <?php endif; ?>"  name="option_text_en[]" value="<?php echo e(old('option_text_en')); ?>" >
        <span class="help-block"><?php if($errors->has('option_text_en')): ?>
                <?php echo e($errors->first('option_text_en')); ?>

            <?php endif; ?></span>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label">Option Arabic Text</label>
    <div class="col-sm-10">
        <input type="text" class="required form-control <?php if($errors->has('option_text_ar')): ?> is-valid <?php endif; ?>"  name="option_text_ar[]" value="<?php echo e(old('option_text_ar')); ?>" >
        <span class="help-block"><?php if($errors->has('option_text_ar')): ?>
                <?php echo e($errors->first('option_text_ar')); ?>

            <?php endif; ?></span>
    </div>
</div>
                                    
                                  <?php endfor; ?><?php /**PATH /home/bakar/Servey/resources/views/panel/includes/single_type.blade.php ENDPATH**/ ?>