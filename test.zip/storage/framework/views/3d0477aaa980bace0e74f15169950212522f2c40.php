<?php $__env->startSection('content'); ?>

        <div class="row">
                 <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
                             <li class="breadcrumb-item"><span>Companies</span></li>
                              <li class="breadcrumb-item"><a href="<?php echo e(route('company.index')); ?>">Companies</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Edit Company</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                        <div class="col-sm-12">
                 <?php if(Session::has('success')): ?>
                  <div class="alert alert-success" role="alert">
                    <?php echo e(Session('success')); ?>

                  </div>
                  <?php endif; ?>
                         <div class="card-body">
                      
                              <form class="form-horizontal tasi-form" method="POST" action="<?php echo e(route('company.update',encrypt($company->company_id))); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('PUT'); ?>
                                   <div class="form-group">
                                      <label class="col-sm-2 control-label">Company English Name</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('company_name_en')): ?> is-valid <?php endif; ?>"  name="company_name_en" value="<?php echo e($company->company_name_en); ?>" >
                                          <span class="help-block"><?php if($errors->has('company_name_en')): ?>
                                                  <?php echo e($errors->first('company_name_en')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                   <div class="form-group">
                                      <label class="col-sm-2 control-label">Company Arabic Name</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('company_name_ar')): ?> is-valid <?php endif; ?>"  name="company_name_ar" value="<?php echo e($company->company_name_ar); ?>" >
                                          <span class="help-block"><?php if($errors->has('company_name_ar')): ?>
                                                  <?php echo e($errors->first('company_name_ar')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                   <div class="form-group">
                                        <label class="col-lg-2 control-label"  for="company_logo">Company Logo </label>
                                        <div class="col-lg-10">
                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                    <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                                      <?php if($company->company_logo === null): ?>
                                                          <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" />
                                                      <?php else: ?>
                                                          <img src="<?php echo e(asset($company->company_logo)); ?>" alt="" />
                                                      <?php endif; ?>
                                                    </div>
                                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                                    <div>
                                                     <span class="btn btn-white btn-file">
                                                     <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select image</span>
                                                     <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                                     <input type="file" name="company_logo" class="default" value="<?php echo e(old('company_logo')); ?>" />
                                                     </span>
                                                        
                                                        
                                                    </div>
                                                     <div class="form-text text-muted">
                                                           <?php if($errors->has('company_logo')): ?>
                                                              <?php echo e($errors->first('company_logo')); ?>

                                                          <?php endif; ?>
                                                         </div>
                                                </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                      <label class="col-sm-2 control-label ">App Background Color </label>
                                      <div class="col-sm-10">
                                          <div id="cp5b" class="input-group colorpicker-component colorpicker-element" title="Using format option" data-colorpicker-id="7">
                                              <input type="text" class="required form-control input-lg" name="company_color" value="<?php echo e($company->company_color); ?>">
                                              <div class="input-group-append">
                                                  <span class="input-group-addon btn btn-outline-secondary"><i style="background-color: rgb(49, 195, 178);"></i></span>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                        <label class="col-lg-2 control-label"  for="company_background">Company Background (Optional)</label>
                                        <div class="col-lg-10">
                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                    <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                                      <?php if($company->company_background === null): ?>
                                                          <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" />
                                                      <?php else: ?>
                                                          <img src="<?php echo e(asset($company->company_background)); ?>" alt="" />
                                                      <?php endif; ?>
                                                    </div>
                                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                                    <div>
                                                     <span class="btn btn-white btn-file">
                                                     <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select image</span>
                                                     <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                                     <input type="file" name="company_background" class="default" value="<?php echo e(old('company_background')); ?>" />
                                                     </span>
                                                        
                                                        
                                                    </div>
                                                     <div class="form-text text-muted">
                                                           <?php if($errors->has('company_background')): ?>
                                                              <?php echo e($errors->first('company_background')); ?>

                                                          <?php endif; ?>
                                                         </div>
                                                </div>
                                        </div>
                                    </div>
                                   <div class="form-group">
                                        <label class="col-sm-2 control-label col-sm-2">Company Address English (Optional)</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control ckeditor" name="company_address_en" rows="6"><?php echo e($company->company_address_en); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label col-sm-2">Company Address Arabic (Optional)</label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control ckeditor" name="company_address_ar" rows="6"><?php echo e($company->company_address_ar); ?></textarea>
                                        </div>
                                    </div>
                                     <div class="form-group">
                                      <label class="col-sm-2 control-label">Mobile Number (Optional)</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="number form-control <?php if($errors->has('company_phone')): ?> is-valid <?php endif; ?>"  name="company_phone" value="<?php echo e($company->company_phone); ?>">
                                          <span class="help-block"><?php if($errors->has('company_phone')): ?>
                                                  <?php echo e($errors->first('company_phone')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                              
                                  
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="<?php echo e(route('company.index')); ?>" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                        
                            
                         </div>
                      </section>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/company/edit.blade.php ENDPATH**/ ?>