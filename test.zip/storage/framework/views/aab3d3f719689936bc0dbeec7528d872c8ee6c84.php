<p style="text-transform: capitalize;">Hello <?php echo e($data['customer_name']); ?>,</p> 
<p>Thank you for last review on branch <?php echo e($data['branch_name']); ?> for company  <?php echo e($data['company_name_en']); ?></p>
<p>because we care about you ,</p>
<p>kindly you can review branch <a href="<?php echo e(route('review.guest',encrypt($data['review_id']))); ?>">Here</a></p>
<p><?php echo e($data['company_name_en']); ?> Team .</p><?php /**PATH /home/bakar/Servey/resources/views/mails/reviewRequest.blade.php ENDPATH**/ ?>