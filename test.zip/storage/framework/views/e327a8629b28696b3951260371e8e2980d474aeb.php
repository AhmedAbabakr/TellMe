<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Tell Me">
    <meta name="keyword" content="Tell Me, rating">
    <link rel="shortcut icon" href="<?php echo e(asset('img/faviconx.png')); ?>">

    <title>Tell Me -  Control Panel</title>

    <!-- Bootstrap core CSS -->
   <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet" />
</head>

  <body class="login-body">

    <div class="container">
   
      <form class="form-signin" method="POST" action="<?php echo e(url('/')); ?>" id="commentForm">
          <?php echo csrf_field(); ?>
          <?php echo method_field('post'); ?>
        <h2 class="form-signin-heading">sign in now</h2>
        <div class="login-wrap">
        
             <input id="email" type="text" class="form-control<?php echo e($errors->has('login') ? ' is-invalid' : ''); ?>" name="login" value="<?php echo e(old('login')); ?>" placeholder="<?php echo e(__('Username') . ' Or '.  __('Email')); ?>" required autofocus>
             <?php if($errors->has('login') || $errors->has('admin_email') || $errors->has('admin_username')  ): ?>
                <span  role="alert" style="padding-bottom: 1%">
                    <strong ><?php echo e($errors->first('login')); ?><?php echo e($errors->first('admin_email')); ?><?php echo e($errors->first('admin_username')); ?></strong>
                </span>
              <?php endif; ?>
                              
             <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" name="password" required>
             <?php if($errors->has('password')): ?>
                <span >
                    <strong ><?php echo e($errors->first('password')); ?></strong>
                </span>
              <?php endif; ?>
            <label class="checkbox">
                
                <input  type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember me
            </label>
            <button class="btn btn-lg btn-login btn-block" type="submit">Sign in</button>
      
          
           

        </div>

        

      </form>

    </div>



    <!-- js placed at the end of the document so the pages load faster -->
 <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
     <script type="text/javascript" src="{!!asset('js/jquery.validate.min.js')}}"></script>
    <script src="<?php echo e(asset('js/common-scripts.js')); ?>"></script>
    <script type="text/javascript" charset="utf-8">
       $(document).ready(function() {
              $("#commentForm").validate();
          } );
    </script>

  </body>
  <footer class="site-footer" style="position: absolute;bottom: 0;width: 100%;">
          <div class="text-center">
              <?php echo e(date('Y')); ?> &copy;<a href="hashcode.me" style="color: #fff">Hash Code</a>.
              
          </div>
      </footer>
</html>
<?php /**PATH /home/bakar/Servey/resources/views/auth/login.blade.php ENDPATH**/ ?>