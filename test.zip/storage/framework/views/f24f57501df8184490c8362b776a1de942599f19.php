<?php $__env->startSection('content'); ?>

             <div class="row">
                   <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
                             <li class="breadcrumb-item"><span>Companies</span></li>
                              <li class="breadcrumb-item"><a href="<?php echo e(route('branch.index')); ?>">Company Branches</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Edit Branch</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                        <div class="col-sm-12">
                 <?php if(Session::has('success')): ?>
                  <div class="alert alert-success" role="alert">
                    <?php echo e(Session('success')); ?>

                  </div>
                  <?php endif; ?>
                         <div class="card-body">
                      
                              <form class="form-horizontal tasi-form" method="POST" action="<?php echo e(route('branch.update',encrypt($branch->branch_id))); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('PUT'); ?>
                                  <?php if(auth()->user()->company === null): ?>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Company </label>
                                      <div class="col-sm-10">
                                          <select class="required number form-control <?php if($errors->has('company_id')): ?> is-valid <?php endif; ?>" name="company_id" >
                                             <option  value="" disabled="disabled" selected="">Select Company</option>
                                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($company->company_id); ?>" 
                                                        
                                                        <?php if($branch->company_id == $company->company_id): ?>

                                                           <?php echo e("selected"); ?>

                                                        <?php endif; ?> ><?php echo e($company->company_name_en); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                          <span class="help-block"><?php if($errors->has('company_id')): ?>
                                                  <?php echo e($errors->first('company_id')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php endif; ?>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Branch Name</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('branch_name')): ?> is-valid <?php endif; ?>" id="namee" name="branch_name" value="<?php echo e($branch->branch_name); ?>" >
                                          <span class="help-block"><?php if($errors->has('branch_name')): ?>
                                                  <?php echo e($errors->first('branch_name')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Branch Code </label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('branch_code')): ?> is-valid <?php endif; ?>"  name="branch_code" value="<?php echo e($branch->branch_code); ?>">
                                          <span class="help-block"><?php if($errors->has('branch_code')): ?>
                                                  <?php echo e($errors->first('branch_code')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                              
                                  
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="<?php echo e(route('branch.index')); ?>" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                        
                            
                         </div>
                      </section>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/branches/edit.blade.php ENDPATH**/ ?>