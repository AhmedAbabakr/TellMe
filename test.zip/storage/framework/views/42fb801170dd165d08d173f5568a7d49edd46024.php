<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Tell Me">
    <meta name="keyword" content="Tell Me, rating">
    <link rel="shortcut icon" href="<?php echo e(asset('img/faviconx.png')); ?>">

    <title>Tell Me </title>

    <!-- Bootstrap core CSS -->
   <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet" />
</head>
<body class="full-width">
  <section id="container" >
     <section>
                  <div class="card card-primary">
                      <!--<div class="card-heading navyblue"> INVOICE</div>-->
                      <div class="card-body">
                          <div class="row invoice-list">
                              <div class="col-md-12 text-center corporate-id">
                                  <img src="<?php echo e(asset('img/Logo.png')); ?>" alt="">
                              </div>
                              <div class="col-md-12 text-center">
                                  <h4>Review Information</h4>
                                  <p>
                                      <?php echo e($review->customer_name); ?> <br>
                                      <?php echo e($review->customer_email); ?> <br>
                                      <?php echo e($review->branch->branch_name); ?> <br>
                                      <?php echo e($review->company->company_name_en); ?><br>
                                  </p>
                              </div>
                             
                          </div>

                          <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-10 mx-auto text-center form p-4">
                      <section class="card">
                         <div class="card-body">
                      
                              <form  class="justify-content-center" method="POST" action="<?php echo e(route('review.guest.store',encrypt($review->review_id))); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('POST'); ?>
                                 
                                 <?php for($i = 0 ; $i < count($questions); $i++): ?>
                                 <?php if($questions[$i]->question->question_type === 0 ||$questions[$i]->question->question_type === 3 ): ?>
                                  <div class="form-group row">
                                      <label class="col-sm-4 control-label"><?php echo e($questions[$i]->question->question_content_en); ?> </label>
                                      <input type="hidden" name="question_id[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question_id); ?>">
                                      <input type="hidden" name="question_type[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question->question_type); ?>">
                                      <div class="col-sm-8">
                                          <select class="required number form-control <?php if($errors->has('option_id')): ?> is-valid <?php endif; ?> " name="option_id[<?php echo e($i); ?>][]" >
                                             <option  value="" disabled="disabled" selected="">Select Option</option>
                                                       <?php $__currentLoopData = $questions[$i]->question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                         <option value="<?php echo e($option->option_id); ?>" 
                                                        
                                                        <?php if(old('option_id') == $option->option_id): ?>

                                                           <?php echo e("selected"); ?>

                                                        <?php endif; ?> ><?php echo e($option->option_text_en); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                          <span class="help-block"><?php if($errors->has('option_id')): ?>
                                                  <?php echo e($errors->first('option_id')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php elseif($questions[$i]->question->question_type === 4): ?>
                                      <input type="hidden" name="question_id[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question_id); ?>">
                                      <input type="hidden" name="question_type[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question->question_type); ?>">
                                  <div class="form-group row">
                                      <label class="col-sm-4 control-label"><?php echo e($questions[$i]->question->question_content_en); ?> </label>
                                      <div class="col-sm-8">
                                          <select class="required number form-control <?php if($errors->has('option_text')): ?> is-valid <?php endif; ?> " name="option_text[<?php echo e($i); ?>]" >
                                             <option  value="" disabled="disabled" selected="">Select Option</option>
                                                       
                                                         <option value="1" <?php if(old('option_text') == 1): ?><?php echo e("selected"); ?><?php endif; ?> >1 Star</option>
                                                         <option value="2" <?php if(old('option_text') == 2): ?><?php echo e("selected"); ?><?php endif; ?> >2 Star</option>
                                                         <option value="3" <?php if(old('option_text') == 3): ?><?php echo e("selected"); ?><?php endif; ?> >3 Star</option>
                                                         <option value="4" <?php if(old('option_text') == 4): ?><?php echo e("selected"); ?><?php endif; ?> >4 Star</option>
                                                         <option value="5" <?php if(old('option_text') == 4): ?><?php echo e("selected"); ?><?php endif; ?> >5 Star</option>
                                                      
                                          </select>
                                          <span class="help-block"><?php if($errors->has('option_text')): ?>
                                                  <?php echo e($errors->first('option_text')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php elseif($questions[$i]->question->question_type === 5): ?>
                                      <input type="hidden" name="question_id[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question_id); ?>">
                                      <input type="hidden" name="question_type[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question->question_type); ?>">
                                   <div class="form-group row">
                                      <label class="col-sm-4 control-label"><?php echo e($questions[$i]->question->question_content_en); ?> </label>
                                      <div class="col-sm-8">
                                          <select class="required number form-control <?php if($errors->has('option_text')): ?> is-valid <?php endif; ?> " name="option_text[<?php echo e($i); ?>]" >
                                             <option  value="" disabled="disabled" selected="">Select Option</option>
                                                       
                                                         <option value="1" <?php if(old('option_text') == 1): ?><?php echo e("selected"); ?><?php endif; ?> >Sad</option>
                                                         <option value="2" <?php if(old('option_text') == 2): ?><?php echo e("selected"); ?><?php endif; ?> >Somewhat sad</option>
                                                         <option value="3" <?php if(old('option_text') == 3): ?><?php echo e("selected"); ?><?php endif; ?> >Neutral</option>
                                                         <option value="4" <?php if(old('option_text') == 4): ?><?php echo e("selected"); ?><?php endif; ?> >Somewhat happy</option>
                                                         <option value="5" <?php if(old('option_text') == 4): ?><?php echo e("selected"); ?><?php endif; ?> >Happy</option>
                                                      
                                          </select>
                                          <span class="help-block"><?php if($errors->has('option_text')): ?>
                                                  <?php echo e($errors->first('option_text')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php elseif($questions[$i]->question->question_type === 2): ?>
                                   <div class="form-group row">
                                      <input type="hidden" name="question_id[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question_id); ?>">
                                      <input type="hidden" name="question_type[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question->question_type); ?>">
                                      <label class="col-sm-4 control-label"><?php echo e($questions[$i]->question->question_content_en); ?> </label>
                                      <div class="col-sm-8">
                                         <textarea rows="4" class="form-control" name="option_text[<?php echo e($i); ?>]"></textarea>
                                          <span class="help-block"><?php if($errors->has('admin_type')): ?>
                                                  <?php echo e($errors->first('admin_type')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php elseif($questions[$i]->question->question_type === 1): ?>
                                   <div class="form-group row">
                                      <input type="hidden" name="question_id[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question_id); ?>">
                                      <input type="hidden" name="question_type[<?php echo e($i); ?>][]" value="<?php echo e($questions[$i]->question->question_type); ?>">
                                      <label class="col-sm-4 control-label"><?php echo e($questions[$i]->question->question_content_en); ?> </label>
                                      <?php $__currentLoopData = $questions[$i]->question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                      <div class="col-sm-12  custom-control custom-checkbox  mb-3">
                                              <input type="checkbox" class="custom-control-input" id="customCheck<?php echo e($option->option_id); ?>" name="option_id[<?php echo e($i); ?>][]" value="<?php echo e($option->option_id); ?>">
                                              <label class="custom-control-label " for="customCheck<?php echo e($option->option_id); ?>" style="position: absolute;"><?php echo e($option->option_text_en); ?></label>
                                          <span class="help-block"><?php if($errors->has('admin_type')): ?>
                                                  <?php echo e($errors->first('admin_type')); ?>

                                              <?php endif; ?></span>
                                              <br>
                                      </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </div>
                                  <?php endif; ?>
                                 <?php endfor; ?>
                                 
                                  <div class="form-group">
                                      
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="<?php echo e(route('admins_user.index')); ?>" class="btn btn-default" type="button">Cancel</a>
                                      
                                  </div>
                              </form>
                        
                            
                         </div>
                      </section>
                </div>
              </div>
                      </div>
                  </div>
              </section>

      </section>

    <!-- js placed at the end of the document so the pages load faster -->
 <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
     <script type="text/javascript" src="{!!asset('js/jquery.validate.min.js')}}"></script>
    <script src="<?php echo e(asset('js/common-scripts.js')); ?>"></script>
    <script type="text/javascript" charset="utf-8">
       $(document).ready(function() {
              $("#commentForm").validate();
          } );
    </script>

  </body>
  <footer class="site-footer" >
          <div class="text-center">
              <?php echo e(date('Y')); ?> &copy;<a href="hashcode.me" style="color: #fff">Hash Code</a>.
              
          </div>
      </footer>
</html>
<?php /**PATH /home/bakar/Servey/resources/views/guest/index.blade.php ENDPATH**/ ?>