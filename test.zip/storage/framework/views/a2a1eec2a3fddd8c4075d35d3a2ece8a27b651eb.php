<?php $__env->startSection('content'); ?>

     <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Home</a></li>
                              <li class="breadcrumb-item"><a href="<?php echo e(route('question.index')); ?>">Questions Bank</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Add Question</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                         <div class="card-body">
                      <?php if($errors->any()): ?>
                          <div class="alert alert-danger">
                              <ul>
                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><?php echo e($error); ?></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </div>
                      <?php endif; ?>
                              <form class="form-horizontal tasi-form" method="POST" action="<?php echo e(route('question.store')); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('POST'); ?>
                                 <?php if(auth()->user()->company === null): ?>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Company </label>
                                      <div class="col-sm-10">
                                          <select class="required number form-control <?php if($errors->has('company_id')): ?> is-valid <?php endif; ?>" name="company_id" >
                                             <option  value="" disabled="disabled" selected="">Select Company</option>
                                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <option value="<?php echo e($company->company_id); ?>" 
                                                        
                                                        <?php if(old('company_id') == $company->company_id): ?>

                                                           <?php echo e("selected"); ?>

                                                        <?php endif; ?> ><?php echo e($company->company_name_en); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                          <span class="help-block"><?php if($errors->has('company_id')): ?>
                                                  <?php echo e($errors->first('company_id')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php endif; ?>
                                   <div class="form-group">
                                      <label class="col-sm-2 control-label">Question Type </label>
                                      <div class="col-sm-10">
                                          <select class="required  form-control <?php if($errors->has('question_type')): ?> is-valid <?php endif; ?>" name="question_type" id="question_type" >
                                             <option  value="" disabled="disabled" selected="">Select Type</option>
                                                        

                                                        <option value="0" <?php if( old('question_type') == 0): ?><?php echo e("selected"); ?><?php endif; ?> >Single Choice Questions</option>
                                                        <option value="1" <?php if( old('question_type') == 1): ?><?php echo e("selected"); ?><?php endif; ?> >Multiple Choice Questions</option>
                                                        <option value="2" <?php if( old('question_type') == 2): ?><?php echo e("selected"); ?><?php endif; ?> >Text Question</option>
                                                        <option value="3" <?php if( old('question_type') == 3): ?><?php echo e("selected"); ?><?php endif; ?> >Images Question</option>
                                                        <option value="4" <?php if( old('question_type') == 4): ?><?php echo e("selected"); ?><?php endif; ?> >Star Question</option>
                                                        <option value="5" <?php if( old('question_type') == 5): ?><?php echo e("selected"); ?><?php endif; ?> >Smile Question</option>
                                                       
                                          </select>
                                          <span class="help-block"><?php if($errors->has('question_type')): ?>
                                                  <?php echo e($errors->first('question_type')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Question English Content</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('question_content_en')): ?> is-valid <?php endif; ?>"  name="question_content_en" value="<?php echo e(old('question_content_en')); ?>" >
                                          <span class="help-block"><?php if($errors->has('question_content_en')): ?>
                                                  <?php echo e($errors->first('question_content_en')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Question Arabic Content</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('question_content_ar')): ?> is-valid <?php endif; ?>"  name="question_content_ar" value="<?php echo e(old('question_content_ar')); ?>" >
                                          <span class="help-block"><?php if($errors->has('question_content_ar')): ?>
                                                  <?php echo e($errors->first('question_content_ar')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group" id="1" >
                                   
                                  </div>
                              
                                  
                                    
                                 
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="<?php echo e(route('question.index')); ?>" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                       
                           
                         </div>
                      </section>
                </div>
              </div>
              <script type="text/javascript">
<?php if( isset($html) ): ?>
 $("#1").append(<?php echo e($html); ?>)
<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/question/create.blade.php ENDPATH**/ ?>