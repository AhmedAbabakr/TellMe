<?php $__env->startSection('content'); ?>


                         <div class="row">
                         <div class="col-sm-12">
                 <?php if(Session::has('success')): ?>
                  <div class="alert alert-success" role="alert">
                    <?php echo e(Session('success')); ?>

                  </div>
                  <?php endif; ?>
                  </div>
                <div class="col-lg-12">
                      <section class="card">

                         <div class="card-body">
                      
                              <form class="form-horizontal tasi-form" method="POST" action="<?php echo e(route('app.setting.update')); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('PUT'); ?>
                                 <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                  <?php if($setting->setting_key === "MAIL_USERNAME" ): ?>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label"><?php echo e(__("message.$setting->setting_key")); ?></label>
                                        <div class="col-sm-10">
                                            <input type="email" class="required email form-control <?php if($errors->has($setting->setting_key)): ?> is-valid <?php endif; ?>"  name="<?php echo e($setting->setting_key); ?>" value="<?php echo e($setting->setting_value); ?>" >
                                            <span class="help-block"><?php if($errors->has($setting->setting_key)): ?>
                                                    <?php echo e($errors->first($setting->setting_key)); ?>

                                                <?php endif; ?></span>
                                        </div>
                                    </div>
                                      <?php elseif($setting->setting_key === "MAIL_PASSWORD"): ?>
                                         <div class="form-group">
                                        <label class="col-sm-2 control-label"><?php echo e(__("message.$setting->setting_key")); ?></label>
                                        <div class="col-sm-10">
                                            <input type="password" class="required  form-control <?php if($errors->has($setting->setting_key)): ?> is-valid <?php endif; ?>"  name="<?php echo e($setting->setting_key); ?>" value="<?php echo e($setting->setting_value); ?>" >
                                            <span class="help-block"><?php if($errors->has($setting->setting_key)): ?>
                                                    <?php echo e($errors->first($setting->setting_key)); ?>

                                                <?php endif; ?></span>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                     <div class="form-group">
                                        <label class="col-sm-2 control-label"><?php echo e(__("message.$setting->setting_key")); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="required  form-control <?php if($errors->has($setting->setting_key)): ?> is-valid <?php endif; ?>"  name="<?php echo e($setting->setting_key); ?>" value="<?php echo e($setting->setting_value); ?>" >
                                            <span class="help-block"><?php if($errors->has($setting->setting_key)): ?>
                                                    <?php echo e($errors->first($setting->setting_key)); ?>

                                                <?php endif; ?></span>
                                        </div>
                                    </div>
                                      <?php endif; ?>
                                 
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                        
                            
                         </div>
                      </section>
                </div>
              </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/settings/setting.blade.php ENDPATH**/ ?>