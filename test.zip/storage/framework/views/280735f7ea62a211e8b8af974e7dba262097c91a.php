<?php $__env->startSection('content'); ?>
              <!-- page start-->
              <section class="card">
                  <header class="card-header">
                      Review Details
                      <span class="pull-right">
                          
                          <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-warning" type="button"><i class="fa fa-reply"></i> Back</a>
                      </span>
                  </header>

              </section>
              <div class="row">
                  <div class="col-md-12">
                      <section class="card">
                          <div class="bio-graph-heading project-heading">
                              <strong> Review Details </strong>
                          </div>
                          <div class="card-body bio-graph-info">
                              <!--<h1>New Dashboard BS3 </h1>-->
                              <div class="row p-details">
                                  <div class="bio-row">
                                      <p><span >Branch </span>: <?php echo e($review->branch->branch_name); ?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span >Company </span>: <?php echo e($review->company->company_name_en); ?></p>
                                  </div>
                                  <div class="bio-row">
                                      <p><span >Customer </span>: <?php echo e($review->customer_name); ?></p>
                                  </div>
                                  <?php if($review->customer_phone !== null): ?>
                                  <div class="bio-row">
                                      <p><span >Phone</span>: <?php echo e($review->customer_phone); ?></p>
                                  </div>
                                  <?php endif; ?>
                                  <?php if($review->customer_email !== null): ?>
                                  <div class="bio-row">
                                      <p><span >Email </span>: <?php echo e($review->customer_email); ?> </p>
                                  </div>
                                  <?php endif; ?>
                                  <?php if($review->customer_contact_method !== null): ?>
                                  <div class="bio-row">
                                      <p><span >Contact Method </span>: <?php echo e($review->customer_contact_method); ?></p>
                                  </div>
                                  <?php endif; ?>
                                  <div class="bio-row">
                                      <p><span >Created Time </span>: <?php echo e($review->created_at->format('d M Y H:m')); ?></p>
                                  </div>
                                  <?php if($review->customer_note !== null): ?>
                                  <div class="col-lg-12">
                                      <div class="mtop20">
                                        
                                          <div >Customer Note:</div>
                                          <p><?php echo e($review->customer_note); ?></p>
                                      </div>
                                      
                                  </div>
                                  <?php endif; ?>
                              </div>

                          </div>

                      </section>

                      <section class="card">
                        <header class="card-header">
                          Questions And Answers
                        </header>
                        <div class="card-body">
                            <?php $__currentLoopData = $review->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="classic-search">
                              <h4><?php echo e($answer->question->question_content_en); ?></h4>
                              
                              <?php if($answer->question->question_type === 0): ?>
                                <p>- <?php echo e($answer->options->option_text_en); ?> </p>
                              <?php elseif($answer->question->question_type === 1): ?>
                                <p>- <?php echo e($answer->options->option_text_en); ?> </p>
                              <?php elseif($answer->question->question_type === 2): ?>
                                <p>- <?php echo e($answer->option_text); ?> </p>
                              <?php elseif($answer->question->question_type === 3): ?>
                                <p>- <?php echo e($answer->options->option_text_en); ?> </p>
                              <?php elseif($answer->question->question_type === 4): ?>
                                <?php if((int)$answer->option_text): ?>
                                  <p>-  
                                    <?php for($i=1;$i<= (int)$answer->option_text;$i++): ?>
                                        <i class="fa fa-star"></i>
                                       <?php endfor; ?>
                                        <?php for($i=1;$i <= 5 - (int)$answer->option_text;$i++): ?>
                                              <i class="fa fa-star-o"  ></i>
                                              <?php endfor; ?>
                                 </p>
                                 <?php else: ?>
                                  <p>- Answer Not Valid </p>
                                <?php endif; ?>
                              <?php elseif($answer->question->question_type === 5): ?>
                                <?php if($answer->option_text == 1): ?>
                                  <p>- Sad</p>
                                <?php elseif($answer->option_text == 2): ?>
                                  <p>- Somewhat sad</p>
                                <?php elseif($answer->option_text == 3): ?>
                                  <p>- Neutral</p>
                                <?php elseif($answer->option_text == 4): ?>
                                  <p>- Somewhat happy</p>
                                <?php elseif($answer->option_text == 5): ?>
                                  <p>- Happy</p>
                                <?php endif; ?>
                              <?php endif; ?>
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </div>
                      </section>

                  </div>
                
              </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/customer/show.blade.php ENDPATH**/ ?>