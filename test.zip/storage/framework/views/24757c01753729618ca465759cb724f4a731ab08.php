<?php $__env->startSection('content'); ?>

     <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
                              <li class="breadcrumb-item"><a href="<?php echo e(route('question.index')); ?>">Questions Bank</a></li>
                              <li class="breadcrumb-item "  style="text-transform: capitalize;"><a href="<?php echo e(route('options.index',$question->question_id)); ?>"><?php echo e($question->question_content_en); ?> Options</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Edit Option</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                         <div class="card-body">
                      
                              <form class="form-horizontal tasi-form" method="POST" action="<?php echo e(route('options.update',['question_id'=>encrypt($question->question_id), 'id'=>encrypt($option->option_id)])); ?>" enctype="multipart/form-data" id="commentForm">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('PUT'); ?>
                                    
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Option English Text</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('option_text_en')): ?> is-valid <?php endif; ?>"  name="option_text_en" value="<?php echo e($option->option_text_en); ?>" >
                                          <span class="help-block"><?php if($errors->has('option_text_en')): ?>
                                                  <?php echo e($errors->first('option_text_en')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Option Arabic Text</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('option_text_ar')): ?> is-valid <?php endif; ?>"  name="option_text_ar" value="<?php echo e($option->option_text_ar); ?>" >
                                          <span class="help-block"><?php if($errors->has('option_text_ar')): ?>
                                                  <?php echo e($errors->first('option_text_ar')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <?php if($option->option_type === 3): ?>
                                    <div class="form-group">
                                          <label class="col-lg-2 control-label"  for="option_image">Option Image  </label>
                                          <div class="col-lg-10">
                                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                                      <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                                           <?php if($option->option_image === null): ?>
                                                                <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" />
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset($option->option_image)); ?>" alt="" />
                                                            <?php endif; ?>
                                                      </div>
                                                      <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                                      <div>
                                                       <span class="btn btn-white btn-file">
                                                       <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select File</span>
                                                       <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                                       <input type="file" name="option_image" class="default"  value="<?php echo e(old('option_image')); ?>" />
                                                       </span>
                                                          
                                                          
                                                      </div>
                                                       <div class="form-text text-muted">
                                                             <?php if($errors->has('option_image')): ?>
                                                                <?php echo e($errors->first('option_image')); ?>

                                                            <?php endif; ?>
                                                           </div>
                                                  </div>
                                          </div>
                                    </div>
                                  <?php endif; ?>  
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="<?php echo e(route('options.index',encrypt($question->question_id))); ?>" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                        
                           
                         </div>
                      </section>
                </div>
              </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/option/edit.blade.php ENDPATH**/ ?>