<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(Session('success')); ?>

    </div>
    <?php endif; ?>
        <section class="card">
            <header class="card-header">
                Account Setting
                 
            </header>
            <div class="card-body">
                <form method="post" action="<?php echo e(route('settings.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                     <div class="form-group">
                                      <label class="col-sm-2 control-label">Admin Name</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('admin_name')): ?> is-valid <?php endif; ?>" id="namee" name="admin_name" value="<?php echo e(auth()->user()->admin_name); ?>" >
                                          <span class="help-block"><?php if($errors->has('admin_name')): ?>
                                                  <?php echo e($errors->first('admin_name')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Username </label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control <?php if($errors->has('admin_username')): ?> is-valid <?php endif; ?>"  name="admin_username" value="<?php echo e(auth()->user()->admin_username); ?>">
                                          <span class="help-block"><?php if($errors->has('admin_username')): ?>
                                                  <?php echo e($errors->first('admin_username')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                   <div class="form-group">
                                      <label class="col-sm-2 control-label">Email (Optional)</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="form-control <?php if($errors->has('admin_email')): ?> is-valid <?php endif; ?>"  name="admin_email" value="<?php echo e(auth()->user()->admin_email); ?>">
                                          <span class="help-block"><?php if($errors->has('admin_email')): ?>
                                                  <?php echo e($errors->first('admin_email')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  
                                   <div class="form-group">
                                      <label class="col-sm-2 control-label">Password </label>
                                      <div class="col-sm-10">
                                          <input type="password" class="required form-control <?php if($errors->has('admin_password')): ?> is-valid <?php endif; ?>"  name="admin_password" >
                                          <span class="help-block"><?php if($errors->has('admin_password')): ?>
                                                  <?php echo e($errors->first('admin_password')); ?>

                                              <?php endif; ?></span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Confirm Password </label>
                                      <div class="col-sm-10">
                                          <input type="password" class="required form-control <?php if($errors->has('admin_password')): ?> is-valid <?php endif; ?>"  name="admin_password_confirmation" > 
                                      </div>
                                  </div>
                 <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-4">
                          <button class="btn btn-danger" type="submit">Save</button>
                          <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-default" type="button">Cancel</a>
                      </div>
                  </div>
                </form>

            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bakar/Servey/resources/views/panel/user/setting.blade.php ENDPATH**/ ?>